<?php

return [
    'api_key' => env('OXAPAY_API_KEY', ''),
    'callback_url' => env('OXAPAY_CALLBACK_URL', ''),
];
